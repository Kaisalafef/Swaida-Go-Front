// lib/features/auth/presentation/screens/forgot_password_screen.dart
//
// نسيت كلمة المرور — خطوتان في شاشة واحدة:
//   1) إدخال البريد            → POST /auth/forgot-password   (يصل رمز من 6 أرقام)
//   2) الرمز + كلمة مرور جديدة → POST /auth/reset-password
// بعد النجاح يعود المستخدم لشاشة الدخول ليسجّل بكلمة المرور الجديدة.

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../shared/widgets/app_button.dart';
import '../../../../shared/widgets/app_text_field.dart';
import '../../data/repositories/auth_repository.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key, this.initialEmail});

  /// يُمرَّر من شاشة الدخول إن كان المستخدم كتب بريده
  final String? initialEmail;

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _repo = AuthRepository();

  final _emailKey = GlobalKey<FormState>();
  final _resetKey = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _code = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();

  bool _codeSent = false; // false = الخطوة 1، true = الخطوة 2
  bool _busy = false;
  String? _error;

  Timer? _timer;
  int _cooldown = 0; // ثواني حتى يُسمح بإعادة الإرسال

  @override
  void initState() {
    super.initState();
    final e = widget.initialEmail?.trim();
    if (e != null && e.isNotEmpty) _email.text = e;
  }

  @override
  void dispose() {
    _timer?.cancel();
    _email.dispose();
    _code.dispose();
    _password.dispose();
    _confirm.dispose();
    super.dispose();
  }

  // ── Helpers ─────────────────────────────────────────────
  static final RegExp _emailRe = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');

  void _startCooldown(int seconds) {
    _timer?.cancel();
    setState(() => _cooldown = seconds);
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return t.cancel();
      if (_cooldown <= 1) {
        t.cancel();
        setState(() => _cooldown = 0);
      } else {
        setState(() => _cooldown--);
      }
    });
  }

  void _snack(String text, {bool error = false}) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(text, style: GoogleFonts.cairo()),
        backgroundColor: error ? AppColors.error : AppColors.success,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(16),
      ));
  }

  // ── Step 1: إرسال الرمز ──────────────────────────────────
  Future<void> _sendCode({bool resend = false}) async {
    if (!resend && !_emailKey.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final wait = await _repo.forgotPassword(email: _email.text.trim());
      if (!mounted) return;
      setState(() => _codeSent = true);
      _startCooldown(wait);
      if (resend) _snack('أعدنا إرسال الرمز إن كان البريد مسجلاً');
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  // ── Step 2: تعيين كلمة المرور ────────────────────────────
  Future<void> _reset() async {
    if (!_resetKey.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await _repo.resetPassword(
        email: _email.text.trim(),
        code: _code.text.trim(),
        newPassword: _password.text,
      );
      if (!mounted) return;
      _snack('تم تعيين كلمة المرور. سجّل الدخول بكلمة المرور الجديدة.');
      context.go('/login');
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _backToEmail() {
    _timer?.cancel();
    setState(() {
      _codeSent = false;
      _cooldown = 0;
      _error = null;
      _code.clear();
      _password.clear();
      _confirm.clear();
    });
  }

  // ═════════════════════════════════════════════════════════
  // BUILD
  // ═════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF4F7F5),
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          scrolledUnderElevation: 0,
          iconTheme: const IconThemeData(color: AppColors.accent),
          title: Text('استعادة كلمة المرور',
              style: GoogleFonts.cairo(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: AppColors.accent)),
          leading: IconButton(
            tooltip: 'رجوع',
            icon: const Icon(Icons.arrow_back_rounded),
            onPressed: () {
              if (_codeSent && !_busy) {
                _backToEmail();
              } else {
                context.canPop() ? context.pop() : context.go('/login');
              }
            },
          ),
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 32),
            children: [
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 16,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: _codeSent ? _buildResetStep() : _buildEmailStep(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── الخطوة 1 ────────────────────────────────────────────
  Widget _buildEmailStep() {
    return Form(
      key: _emailKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _header(Icons.lock_reset_rounded, 'نسيت كلمة المرور؟',
              'اكتب بريدك الإلكتروني وسنرسل إليه رمزاً من 6 أرقام لإعادة تعيين كلمة المرور.'),
          const SizedBox(height: 20),
          AppTextField(
            label: 'البريد الإلكتروني',
            hint: 'name@example.com',
            controller: _email,
            prefixIcon: Icons.email_outlined,
            keyboardType: TextInputType.emailAddress,
            textDirection: TextDirection.ltr,
            textInputAction: TextInputAction.done,
            onFieldSubmitted: (_) => _sendCode(),
            validator: (v) {
              final t = v?.trim() ?? '';
              if (t.isEmpty) return 'البريد الإلكتروني مطلوب';
              if (!_emailRe.hasMatch(t)) return 'صيغة البريد غير صحيحة';
              return null;
            },
          ),
          if (_error != null) ...[
            const SizedBox(height: 12),
            _errorBox(_error!),
          ],
          const SizedBox(height: 20),
          AppButton(
            label: 'إرسال الرمز',
            isLoading: _busy,
            onPressed: _busy ? null : _sendCode,
          ),
        ],
      ),
    );
  }

  // ── الخطوة 2 ────────────────────────────────────────────
  Widget _buildResetStep() {
    return Form(
      key: _resetKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _header(
            Icons.mark_email_read_rounded,
            'أدخل الرمز',
            'إن كان البريد ${_email.text.trim()} مسجلاً لدينا فقد وصله رمز من 6 أرقام، '
                'وهو صالح 15 دقيقة. افحص الرسائل غير المرغوبة أيضاً.',
          ),
          const SizedBox(height: 20),
          TextFormField(
            controller: _code,
            keyboardType: TextInputType.number,
            textDirection: TextDirection.ltr,
            textAlign: TextAlign.center,
            maxLength: 6,
            autofocus: true,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            style: GoogleFonts.cairo(
                fontSize: 28,
                fontWeight: FontWeight.w800,
                letterSpacing: 10,
                color: AppColors.primary),
            decoration: InputDecoration(
              counterText: '',
              hintText: '------',
              hintStyle: GoogleFonts.cairo(
                  fontSize: 28, letterSpacing: 10, color: AppColors.border),
              filled: true,
              fillColor: AppColors.primarySoft,
              errorStyle: GoogleFonts.cairo(fontSize: 12),
              contentPadding: const EdgeInsets.symmetric(vertical: 16),
              border: _border(AppColors.border),
              enabledBorder: _border(AppColors.border),
              focusedBorder: _border(AppColors.primary, 2),
              errorBorder: _border(AppColors.error),
              focusedErrorBorder: _border(AppColors.error, 2),
            ),
            validator: (v) =>
                (v ?? '').length != 6 ? 'الرمز يتكون من 6 أرقام' : null,
          ),
          const SizedBox(height: 16),
          AppTextField(
            label: 'كلمة المرور الجديدة',
            hint: '8 أحرف على الأقل',
            controller: _password,
            prefixIcon: Icons.lock_outline_rounded,
            obscureText: true,
            textInputAction: TextInputAction.next,
            validator: (v) =>
                (v ?? '').length < 8 ? 'كلمة المرور 8 أحرف على الأقل' : null,
          ),
          const SizedBox(height: 16),
          AppTextField(
            label: 'تأكيد كلمة المرور',
            hint: 'أعد كتابتها',
            controller: _confirm,
            prefixIcon: Icons.lock_outline_rounded,
            obscureText: true,
            textInputAction: TextInputAction.done,
            onFieldSubmitted: (_) => _reset(),
            validator: (v) =>
                v != _password.text ? 'كلمتا المرور غير متطابقتين' : null,
          ),
          if (_error != null) ...[
            const SizedBox(height: 12),
            _errorBox(_error!),
          ],
          const SizedBox(height: 20),
          AppButton(
            label: 'تعيين كلمة المرور',
            isLoading: _busy,
            onPressed: _busy ? null : _reset,
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextButton(
                onPressed: (_cooldown > 0 || _busy)
                    ? null
                    : () => _sendCode(resend: true),
                style: TextButton.styleFrom(minimumSize: const Size(48, 44)),
                child: Text(
                  _cooldown > 0
                      ? 'إعادة الإرسال بعد $_cooldown ث'
                      : 'إعادة إرسال الرمز',
                  style: GoogleFonts.cairo(
                      fontSize: 13, fontWeight: FontWeight.w600),
                ),
              ),
              const Text('·', style: TextStyle(color: AppColors.textMuted)),
              TextButton(
                onPressed: _busy ? null : _backToEmail,
                style: TextButton.styleFrom(minimumSize: const Size(48, 44)),
                child: Text('تغيير البريد',
                    style: GoogleFonts.cairo(
                        fontSize: 13, fontWeight: FontWeight.w600)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── UI helpers ──────────────────────────────────────────
  OutlineInputBorder _border(Color c, [double w = 1.3]) => OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: c, width: w),
      );

  Widget _header(IconData icon, String title, String subtitle) {
    return Column(
      children: [
        Container(
          width: 64,
          height: 64,
          decoration: const BoxDecoration(
              color: AppColors.primarySoft, shape: BoxShape.circle),
          child: Icon(icon, size: 30, color: AppColors.primary),
        ),
        const SizedBox(height: 14),
        Text(title,
            style: GoogleFonts.cairo(
                fontWeight: FontWeight.bold,
                fontSize: 20,
                color: AppColors.accent)),
        const SizedBox(height: 6),
        Text(subtitle,
            textAlign: TextAlign.center,
            style: GoogleFonts.cairo(
                fontSize: 13, color: AppColors.textMuted, height: 1.6)),
      ],
    );
  }

  Widget _errorBox(String text) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.errorLight,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            const Icon(Icons.error_outline_rounded,
                size: 18, color: AppColors.error),
            const SizedBox(width: 8),
            Expanded(
              child: Text(text,
                  style: GoogleFonts.cairo(
                      fontSize: 12.5, color: AppColors.error)),
            ),
          ],
        ),
      );
}
